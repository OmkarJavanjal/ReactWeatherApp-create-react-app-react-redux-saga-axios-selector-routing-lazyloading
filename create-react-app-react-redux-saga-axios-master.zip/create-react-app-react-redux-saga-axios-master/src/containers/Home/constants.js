export const GET_CITY_LIST = 'src/containers/Home/GET_CITY_LIST';
export const GET_CITY_LIST_DONE = 'src/containers/Home/GET_CITY_LIST_DONE';

export const GET_WEATHER = 'src/containers/Home/GET_WEATHER';
export const GET_WEATHER_DONE = 'src/containers/Home/GET_WEATHER_DONE';

export const SET_SELECTED_CITY = 'src/containers/Home/SET_SELECTED_CITY';