import Select from 'react-select';

export default Select;